# BLE Message Protocol (Holiday / Halloween Display Control)

This document defines the **BLE GATT protocol** for controlling the holiday lighting display (Orthanc tower) from a BLE Central (app/device).

It is designed to be:
- **Simple and extensible** (effects + parameters)
- **Platform-agnostic** (works with Nano 33 BLE, ESP32-S3, etc.)
- **Consistent across devices** via a shared UUID scheme and payload format

---
## 1. BLE Service & Characteristics

### 1.1 Service: `HOLIDAY / HALLOWEEN DISPLAY CONTROL`
- **UUID**: `19B10000-E8F2-537E-4F6C-D104768A1214`
- **Properties**: Advertised service, support for Notify + Write on characteristics (see below)

### 1.2 Characteristic: `device_info` (READ ONLY)
- **UUID**: `19B10010-E8F2-537E-4F6C-D104768A1214`
- **Type**: UTF-8 string or small binary struct
- **Purpose**: Allows the app to adapt its UI based on device type/capabilities.

**Recommended format (CSV-like):**
```
<model>,<fw>,<capabilities>,<pixel_count>
```

**Nano example:**
```
NANO33BLE,fw1.0,RGBW,FRAM,8px
```
**S3 example:**
```
ESP32S3,fw1.0,RGBW,AUDIO,FLASH,32px
```

---
### 1.3 Characteristic: `battery_status` (READ + NOTIFY)
- **UUID**: `19B10011-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t` (percentage) or `uint16_t` (millivolts)
- **Meaning**: Reports battery level or raw voltage.

**Nano 33 BLE Rev 2**: report either percentage or raw mV from the divider.

---
### 1.4 Characteristic: `effect_id`
- **UUID**: `19B10001-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t`
- **Meaning**: Select the active lighting effect.

### 1.5 Characteristic: `brightness`
- **UUID**: `19B10002-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t` (0–255)

### 1.6 Characteristic: `speed`
- **UUID**: `19B10003-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t` (controls pulse/transition speed)

### 1.7 Characteristic: `color_primary`
- **UUID**: `19B10004-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint32_t` (0xRRGGBB)

### 1.8 Characteristic: `color_secondary`
- **UUID**: `19B10005-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint32_t` (0xRRGGBB)

### 1.9 Characteristic: `flags`
- **UUID**: `19B10006-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t` bitfield (expandable for future toggles)

### 1.10 Characteristic: `audio_track_id`
- **UUID**: `19B10007-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t`
- **Meaning**: Selects a sound track (ignored on Nano, used on ESP32-S3).

### 1.11 Characteristic: `save_config` (WRITE + NOTIFY)
- **UUID**: `19B10008-E8F2-537E-4F6C-D104768A1214`
- **Type**: `uint8_t` (write `1` to save)

**Behavior**:
- On write(1): device saves current `DisplayConfig` to non-volatile storage.
- Then sends Notify(1) to confirm success.

---
## 2. Shared Config Structure

```cpp
struct DisplayConfig {
    uint8_t  effect_id;
    uint8_t  brightness;
    uint8_t  speed;
    uint32_t color_primary;     // RGB only
    uint32_t color_secondary;   // RGB only
    uint8_t  audio_track_id;    // ignored on Nano
    uint8_t  flags;
};
```

This struct is the canonical configuration payload that can be stored in FRAM or flash and restored at boot.

---
## 3. Effect IDs (Suggested Mapping)

| ID | Effect |
|---:|:-------|
| 0 | Fire (default) |
| 1 | Candle |
| 2 | Ember |
| 3 | Sparkle |
| 4 | WarmWhite |
|10 | LOTR Cold White / Elvish |
|11 | LOTR Palantír Heartbeat |
|12 | LOTR Many-Color Shimmer |

---
## 4. RGBW Handling (W Dominance)

### Guiding Principle
**The app never sends a direct W channel value.** The device computes W internally.

**Why:**
- SK6812 RGBW strips have wildly varying W intensity.
- Raw W values often wash out saturation or blow out brightness.
- Deriving W from RGB keeps the BLE interface simple and consistent.

### Recommended Device Behavior
1. Convert RGB → RGBW algorithmically.
2. Clamp or scale W to avoid overpowering colors.
3. Allow effects to intentionally use W (e.g., candle, ember, warm white).
4. Keep BLE interface RGB-only.

### Simple Algorithm (Min-subtraction, common & fast)
```cpp
uint8_t w = min({r, g, b});
uint8_t wScaled = (uint16_t)w * whiteScale / 255;

r = max(0, r - wScaled);
g = max(0, g - wScaled);
b = max(0, b - wScaled);

// w = wScaled;
```

### Better (Luminance-based, like WLED Accurate)
- Estimates “how white” the color is from the distribution between max/min.
- Produces more natural-looking pastels and mixed colors.

### Calibration (Recommended)
Since W intensity varies per strip, measure:
- Brightness of RGB white (255,255,255)
- Brightness of pure W (0,0,0,255)

Then compute a `whiteScaleFactor` and apply it to the computed W.

---
## 5. UUID Pattern & Board IDs

### UUID generation pattern
All UUIDs share the base suffix: `E8F2-537E-4F6C-D104768A1214`.
The first 32-bit group is `19B1xxxx`, where `xxxx` is a small hex index.

| Purpose | UUID (first group) | Hex index |
|--------|--------------------|----------|
| Service | 19B10000 | 0000 |
| effect_id | 19B10001 | 0001 |
| brightness | 19B10002 | 0002 |
| ... | ... | ... |
| save_config | 19B10008 | 0008 |
| device_info | 19B10010 | 0010 |
| battery_status | 19B10011 | 0011 |

### Board ID encoding (0..99)
Use the **first UUID group** to encode board ID by reserving `xxxx` for the board number.
For example, board ID 0 → `19B10001` (or `19B10000` if reserved for service).

**Extraction (Arduino style):**
```cpp
int getBoardIDFromUUID(const String& uuid) {
  String clean = uuid;
  clean.replace("-", "");
  clean.toUpperCase();
  if (!clean.startsWith("19B1") || clean.length() < 8) return -1;
  String idHex = clean.substring(4, 8);
  int id = (int) strtol(idHex.c_str(), NULL, 16);
  if (id >= 1 && id <= 100) return id - 1;
  return -1;
}
```

- Board ID `0` is treated as the **MASTER** board.
- The board ID is also physically labeled on the bottom of the ceramic structure.

---
## 6. Notes & Best Practices
- Keep BLE characteristics lightweight and structured.
- Persist `DisplayConfig` to FRAM/flash when `save_config` is written.
- If BLE disconnects, continue running the last known effect.
- Keep the BLE interface RGB-only and compute W on-device for consistent results.

---
*This protocol document is designed to be the authoritative reference for BLE control of the Orthanc Holiday display, and to guide both firmware and app development.*
